import type { Food } from '../types';

export const brazilianFoods: Food[] = [
  // Cereais e Derivados
  { id: '1', name: 'Arroz branco, cozido', category: 'Cereais e Derivados', portion: '100', unit: 'g', calories: 128, protein: 2.5, carbs: 28, fat: 0.2, fiber: 0.9, sodium: 1 },
  { id: '2', name: 'Pão francês', category: 'Cereais e Derivados', portion: '50', unit: 'g', calories: 150, protein: 4.5, carbs: 30, fat: 1.5, fiber: 1.2, sodium: 310 },
  { id: '3', name: 'Macarrão, cozido', category: 'Cereais e Derivados', portion: '140', unit: 'g', calories: 158, protein: 5.8, carbs: 31, fat: 1, fiber: 1.8, sodium: 1 },
  { id: '4', name: 'Aveia em flocos', category: 'Cereais e Derivados', portion: '40', unit: 'g', calories: 153, protein: 5.5, carbs: 27, fat: 2.7, fiber: 4, sodium: 1 },
  { id: '5', name: 'Milho verde, cozido', category: 'Cereais e Derivados', portion: '100', unit: 'g', calories: 96, protein: 3.4, carbs: 21, fat: 1.5, fiber: 2.4, sodium: 1 },
  { id: '6', name: 'Pão de forma integral', category: 'Cereais e Derivados', portion: '50', unit: 'g (2 fatias)', calories: 130, protein: 5, carbs: 22, fat: 2.5, fiber: 4, sodium: 220 },
  { id: '7', name: 'Tapioca (goma hidratada)', category: 'Cereais e Derivados', portion: '100', unit: 'g', calories: 239, protein: 0, carbs: 59, fat: 0, fiber: 0, sodium: 10 },
  { id: '8', name: 'Cuscuz de milho, cozido', category: 'Cereais e Derivados', portion: '100', unit: 'g', calories: 113, protein: 2.3, carbs: 25, fat: 0.2, fiber: 1.7, sodium: 3 },
  { id: '9', name: 'Quinoa, cozida', category: 'Cereais e Derivados', portion: '185', unit: 'g', calories: 222, protein: 8.1, carbs: 39.4, fat: 3.6, fiber: 5.2, sodium: 13 },
  { id: '10', name: 'Biscoito cream cracker', category: 'Cereais e Derivados', portion: '30', unit: 'g (5 unidades)', calories: 134, protein: 3.2, carbs: 21.6, fat: 3.9, fiber: 1, sodium: 230 },

  // Verduras e Legumes
  { id: '11', name: 'Alface', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 15, protein: 1.4, carbs: 2.9, fat: 0.2, fiber: 1.3, sodium: 10 },
  { id: '12', name: 'Tomate', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2, fiber: 1.2, sodium: 5 },
  { id: '13', name: 'Cenoura, cozida', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 35, protein: 0.7, carbs: 8.2, fat: 0.2, fiber: 3, sodium: 58 },
  { id: '14', name: 'Brócolis, cozido', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 35, protein: 2.4, carbs: 7.2, fat: 0.4, fiber: 3.3, sodium: 41 },
  { id: '15', name: 'Batata doce, cozida', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 77, protein: 0.6, carbs: 18.4, fat: 0.1, fiber: 2.2, sodium: 36 },
  { id: '16', name: 'Abobrinha, cozida', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 15, protein: 1.1, carbs: 2.2, fat: 0.3, fiber: 1.1, sodium: 1 },
  { id: '17', name: 'Couve refogada', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 90, protein: 2.2, carbs: 5.1, fat: 7.2, fiber: 2.6, sodium: 15 },
  { id: '18', name: 'Espinafre, cozido', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 23, protein: 3, carbs: 3.7, fat: 0.3, fiber: 2.4, sodium: 70 },
  { id: '19', name: 'Pimentão', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 20, protein: 0.86, carbs: 4.64, fat: 0.17, fiber: 1.7, sodium: 3 },
  { id: '20', name: 'Beterraba, cozida', category: 'Verduras e Legumes', portion: '100', unit: 'g', calories: 44, protein: 1.7, carbs: 10, fat: 0.2, fiber: 2, sodium: 65 },

  // Frutas
  { id: '21', name: 'Banana prata', category: 'Frutas', portion: '100', unit: 'g', calories: 98, protein: 1.3, carbs: 26, fat: 0.1, fiber: 2, sodium: 1 },
  { id: '22', name: 'Maçã', category: 'Frutas', portion: '100', unit: 'g', calories: 52, protein: 0.3, carbs: 14, fat: 0.2, fiber: 2.4, sodium: 1 },
  { id: '23', name: 'Laranja', category: 'Frutas', portion: '100', unit: 'g', calories: 47, protein: 0.9, carbs: 12, fat: 0.1, fiber: 2.4, sodium: 0 },
  { id: '24', name: 'Mamão formosa', category: 'Frutas', portion: '100', unit: 'g', calories: 45, protein: 0.5, carbs: 11.6, fat: 0.1, fiber: 1, sodium: 3 },
  { id: '25', name: 'Manga', category: 'Frutas', portion: '100', unit: 'g', calories: 60, protein: 0.8, carbs: 15, fat: 0.4, fiber: 1.6, sodium: 1 },
  { id: '26', name: 'Açaí (polpa congelada)', category: 'Frutas', portion: '100', unit: 'g', calories: 58, protein: 0.8, carbs: 6.2, fat: 3.6, fiber: 2.6, sodium: 5 },
  { id: '27', name: 'Abacate', category: 'Frutas', portion: '100', unit: 'g', calories: 160, protein: 2, carbs: 8.5, fat: 14.7, fiber: 6.7, sodium: 7 },
  { id: '28', name: 'Uva', category: 'Frutas', portion: '100', unit: 'g', calories: 69, protein: 0.7, carbs: 18, fat: 0.2, fiber: 0.9, sodium: 2 },
  { id: '29', name: 'Melancia', category: 'Frutas', portion: '100', unit: 'g', calories: 30, protein: 0.6, carbs: 7.6, fat: 0.2, fiber: 0.4, sodium: 1 },
  { id: '30', name: 'Morango', category: 'Frutas', portion: '100', unit: 'g', calories: 32, protein: 0.7, carbs: 7.7, fat: 0.3, fiber: 2, sodium: 1 },

  // Carnes e Derivados
  { id: '31', name: 'Peito de frango, grelhado', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0, sodium: 74 },
  { id: '32', name: 'Bife de alcatra, grelhado', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 200, protein: 28, carbs: 0, fat: 9, fiber: 0, sodium: 57 },
  { id: '33', name: 'Ovo, cozido', category: 'Carnes e Derivados', portion: '50', unit: 'g (1 unidade)', calories: 77, protein: 6.3, carbs: 0.6, fat: 5.3, fiber: 0, sodium: 62 },
  { id: '34', name: 'Salmão, assado', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 206, protein: 22, carbs: 0, fat: 12, fiber: 0, sodium: 61 },
  { id: '35', name: 'Patinho moído, cozido', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 216, protein: 28, carbs: 0, fat: 11, fiber: 0, sodium: 72 },
  { id: '36', name: 'Tilápia, assada', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 128, protein: 26, carbs: 0, fat: 2.6, fiber: 0, sodium: 52 },
  { id: '37', name: 'Linguiça toscana, frita', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 323, protein: 17, carbs: 1.1, fat: 27, fiber: 0, sodium: 1250 },
  { id: '38', name: 'Atum em lata (em óleo)', category: 'Carnes e Derivados', portion: '85', unit: 'g', calories: 184, protein: 24.8, carbs: 0, fat: 8.2, fiber: 0, sodium: 338 },
  { id: '39', name: 'Lombo de porco, assado', category: 'Carnes e Derivados', portion: '100', unit: 'g', calories: 143, protein: 26, carbs: 0, fat: 3.5, fiber: 0, sodium: 57 },
  { id: '40', name: 'Peito de peru defumado', category: 'Carnes e Derivados', portion: '50', unit: 'g (2 fatias)', calories: 55, protein: 9, carbs: 0.5, fat: 1.5, fiber: 0, sodium: 580 },

  // Leite e Derivados
  { id: '41', name: 'Leite integral', category: 'Leite e Derivados', portion: '200', unit: 'ml', calories: 122, protein: 6.4, carbs: 9.4, fat: 6.6, fiber: 0, sodium: 98 },
  { id: '42', name: 'Queijo minas frescal', category: 'Leite e Derivados', portion: '30', unit: 'g', calories: 73, protein: 5.1, carbs: 0.9, fat: 5.4, fiber: 0, sodium: 180 },
  { id: '43', name: 'Iogurte natural integral', category: 'Leite e Derivados', portion: '170', unit: 'g', calories: 104, protein: 5.9, carbs: 7.9, fat: 5.6, fiber: 0, sodium: 80 },
  { id: '44', name: 'Queijo muçarela', category: 'Leite e Derivados', portion: '30', unit: 'g', calories: 90, protein: 6.7, carbs: 0.7, fat: 6.8, fiber: 0, sodium: 189 },
  { id: '45', name: 'Requeijão cremoso', category: 'Leite e Derivados', portion: '30', unit: 'g (1 colher de sopa)', calories: 78, protein: 3, carbs: 1.2, fat: 6.8, fiber: 0, sodium: 165 },
  { id: '46', name: 'Leite desnatado', category: 'Leite e Derivados', portion: '200', unit: 'ml', calories: 70, protein: 6.8, carbs: 10, fat: 0.2, fiber: 0, sodium: 106 },
  { id: '47', name: 'Queijo cottage', category: 'Leite e Derivados', portion: '100', unit: 'g', calories: 98, protein: 11, carbs: 3.4, fat: 4.3, fiber: 0, sodium: 364 },
  { id: '48', name: 'Iogurte Grego', category: 'Leite e Derivados', portion: '100', unit: 'g', calories: 97, protein: 9, carbs: 10, fat: 2.5, fiber: 0, sodium: 45 },
  { id: '49', name: 'Queijo parmesão ralado', category: 'Leite e Derivados', portion: '10', unit: 'g (1 colher de sopa)', calories: 43, protein: 3.8, carbs: 0.4, fat: 2.9, fiber: 0, sodium: 153 },
  { id: '50', name: 'Creme de leite', category: 'Leite e Derivados', portion: '15', unit: 'g (1 colher de sopa)', calories: 37, protein: 0.3, carbs: 0.4, fat: 3.8, fiber: 0, sodium: 6 },

  // Leguminosas
  { id: '51', name: 'Feijão carioca, cozido', category: 'Leguminosas', portion: '100', unit: 'g', calories: 76, protein: 4.8, carbs: 13.6, fat: 0.5, fiber: 8.5, sodium: 2 },
  { id: '52', name: 'Lentilha, cozida', category: 'Leguminosas', portion: '100', unit: 'g', calories: 116, protein: 9, carbs: 20, fat: 0.4, fiber: 7.9, sodium: 2 },
  { id: '53', name: 'Grão-de-bico, cozido', category: 'Leguminosas', portion: '100', unit: 'g', calories: 139, protein: 7.1, carbs: 24, fat: 2.3, fiber: 6.2, sodium: 7 },
  { id: '54', name: 'Soja, cozida', category: 'Leguminosas', portion: '100', unit: 'g', calories: 173, protein: 17, carbs: 10, fat: 9, fiber: 6, sodium: 2 },
  { id: '55', name: 'Ervilha, enlatada', category: 'Leguminosas', portion: '100', unit: 'g', calories: 65, protein: 4.3, carbs: 11.2, fat: 0.3, fiber: 4.5, sodium: 258 },

  // Oleaginosas
  { id: '56', name: 'Castanha-do-pará', category: 'Oleaginosas', portion: '15', unit: 'g (3 unidades)', calories: 98, protein: 2.1, carbs: 1.8, fat: 10, fiber: 1.1, sodium: 0 },
  { id: '57', name: 'Amendoim, torrado', category: 'Oleaginosas', portion: '30', unit: 'g', calories: 170, protein: 7.3, carbs: 4.6, fat: 14, fiber: 2.4, sodium: 5 },
  { id: '58', name: 'Castanha de caju, torrada', category: 'Oleaginosas', portion: '30', unit: 'g', calories: 163, protein: 4.3, carbs: 9.3, fat: 13, fiber: 0.9, sodium: 4 },
  { id: '59', name: 'Nozes', category: 'Oleaginosas', portion: '30', unit: 'g', calories: 196, protein: 4.3, carbs: 3.9, fat: 18.5, fiber: 1.9, sodium: 1 },
  { id: '60', name: 'Amêndoas', category: 'Oleaginosas', portion: '30', unit: 'g', calories: 173, protein: 6.3, carbs: 6.5, fat: 14.9, fiber: 3.3, sodium: 0 },

  // Óleos e Gorduras
  { id: '61', name: 'Azeite de oliva extra virgem', category: 'Óleos e Gorduras', portion: '15', unit: 'ml (1 colher de sopa)', calories: 119, protein: 0, carbs: 0, fat: 13.5, fiber: 0, sodium: 0 },
  { id: '62', name: 'Manteiga com sal', category: 'Óleos e Gorduras', portion: '10', unit: 'g', calories: 72, protein: 0.1, carbs: 0, fat: 8.1, fiber: 0, sodium: 65 },
  { id: '63', name: 'Óleo de soja', category: 'Óleos e Gorduras', portion: '15', unit: 'ml (1 colher de sopa)', calories: 124, protein: 0, carbs: 0, fat: 14, fiber: 0, sodium: 0 },
  { id: '64', name: 'Margarina', category: 'Óleos e Gorduras', portion: '10', unit: 'g', calories: 72, protein: 0.1, carbs: 0.1, fat: 8, fiber: 0, sodium: 73 },
  { id: '65', name: 'Banha de porco', category: 'Óleos e Gorduras', portion: '15', unit: 'ml (1 colher de sopa)', calories: 115, protein: 0, carbs: 0, fat: 12.8, fiber: 0, sodium: 0 },

  // Açúcares e Doces
  { id: '66', name: 'Açúcar refinado', category: 'Açúcares e Doces', portion: '5', unit: 'g (1 colher de chá)', calories: 20, protein: 0, carbs: 5, fat: 0, fiber: 0, sodium: 0 },
  { id: '67', name: 'Mel', category: 'Açúcares e Doces', portion: '20', unit: 'g (1 colher de sopa)', calories: 61, protein: 0.1, carbs: 16.5, fat: 0, fiber: 0, sodium: 1 },
  { id: '68', name: 'Doce de leite', category: 'Açúcares e Doces', portion: '20', unit: 'g (1 colher de sopa)', calories: 62, protein: 1.4, carbs: 11, fat: 1.6, fiber: 0, sodium: 22 },
  { id: '69', name: 'Goiabada', category: 'Açúcares e Doces', portion: '40', unit: 'g', calories: 139, protein: 0.4, carbs: 35, fat: 0, fiber: 1.6, sodium: 1 },
  { id: '70', name: 'Chocolate ao leite', category: 'Açúcares e Doces', portion: '25', unit: 'g', calories: 135, protein: 2, carbs: 15, fat: 7.5, fiber: 0.9, sodium: 20 },

  // Industrializados
  { id: '71', name: 'Iogurte de morango', category: 'Industrializados', portion: '170', unit: 'g', calories: 145, protein: 5.5, carbs: 24, fat: 2.8, fiber: 0, sodium: 75 },
  { id: '72', name: 'Refrigerante (cola)', category: 'Bebidas', portion: '350', unit: 'ml', calories: 149, protein: 0, carbs: 37, fat: 0, fiber: 0, sodium: 38 },
  { id: '73', name: 'Salsicha', category: 'Industrializados', portion: '50', unit: 'g (1 unidade)', calories: 155, protein: 6, carbs: 1.2, fat: 14, fiber: 0, sodium: 550 },
  { id: '74', name: 'Nuggets de frango, frito', category: 'Industrializados', portion: '100', unit: 'g (6 unidades)', calories: 296, protein: 14, carbs: 15, fat: 19, fiber: 1, sodium: 580 },
  { id: '75', name: 'Lasanha bolonhesa congelada', category: 'Industrializados', portion: '300', unit: 'g', calories: 380, protein: 18, carbs: 36, fat: 18, fiber: 4, sodium: 950 },
  { id: '76', name: 'Pizza de muçarela', category: 'Industrializados', portion: '100', unit: 'g (1 fatia)', calories: 271, protein: 12, carbs: 28, fat: 12, fiber: 1.8, sodium: 640 },
  { id: '77', name: 'Hambúrguer de carne', category: 'Industrializados', portion: '80', unit: 'g', calories: 210, protein: 15, carbs: 0, fat: 16, fiber: 0, sodium: 320 },
  { id: '78', name: 'Molho de tomate pronto', category: 'Industrializados', portion: '60', unit: 'g (3 colheres)', calories: 25, protein: 0.8, carbs: 4.5, fat: 0.3, fiber: 1, sodium: 350 },
  { id: '79', name: 'Macarrão instantâneo', category: 'Industrializados', portion: '85', unit: 'g', calories: 380, protein: 8, carbs: 53, fat: 16, fiber: 2.5, sodium: 1580 },
  { id: '80', name: 'Batata frita (fast food)', category: 'Industrializados', portion: '100', unit: 'g', calories: 312, protein: 3.4, carbs: 41, fat: 15, fiber: 3.8, sodium: 210 },
  
  // Bebidas
  { id: '81', name: 'Suco de laranja natural', category: 'Bebidas', portion: '200', unit: 'ml', calories: 94, protein: 1.4, carbs: 21.6, fat: 0.2, fiber: 0.2, sodium: 2 },
  { id: '82', name: 'Café coado, sem açúcar', category: 'Bebidas', portion: '150', unit: 'ml', calories: 2, protein: 0.2, carbs: 0, fat: 0, fiber: 0, sodium: 3 },
  { id: '83', name: 'Água de coco', category: 'Bebidas', portion: '200', unit: 'ml', calories: 38, protein: 1.4, carbs: 8, fat: 0.2, fiber: 0, sodium: 210 },
  { id: '84', name: 'Cerveja Pilsen', category: 'Bebidas', portion: '350', unit: 'ml', calories: 147, protein: 1, carbs: 12.6, fat: 0, fiber: 0, sodium: 14 },
  { id: '85', name: 'Vinho tinto seco', category: 'Bebidas', portion: '150', unit: 'ml', calories: 125, protein: 0.1, carbs: 3.8, fat: 0, fiber: 0, sodium: 6 },
  
  // Preparações
  { id: '86', name: 'Feijoada', category: 'Preparações', portion: '200', unit: 'g', calories: 300, protein: 15, carbs: 20, fat: 18, fiber: 8, sodium: 800 },
  { id: '87', name: 'Moqueca de peixe', category: 'Preparações', portion: '200', unit: 'g', calories: 250, protein: 20, carbs: 5, fat: 16, fiber: 2, sodium: 500 },
  { id: '88', name: 'Strogonoff de frango', category: 'Preparações', portion: '150', unit: 'g', calories: 280, protein: 25, carbs: 8, fat: 16, fiber: 1, sodium: 600 },
  { id: '89', name: 'Pão de queijo', category: 'Preparações', portion: '50', unit: 'g (2 unidades)', calories: 170, protein: 4, carbs: 20, fat: 8, fiber: 0.5, sodium: 350 },
  { id: '90', name: 'Coxinha de frango', category: 'Preparações', portion: '100', unit: 'g', calories: 260, protein: 12, carbs: 25, fat: 12, fiber: 2, sodium: 550 },
  { id: '91', name: 'Farofa de mandioca', category: 'Preparações', portion: '50', unit: 'g', calories: 210, protein: 0.8, carbs: 40, fat: 5, fiber: 3, sodium: 250 },
  { id: '92', name: 'Salada de maionese', category: 'Preparações', portion: '100', unit: 'g', calories: 160, protein: 2.5, carbs: 15, fat: 10, fiber: 2, sodium: 300 },
  { id: '93', name: 'Arroz de carreteiro', category: 'Preparações', portion: '200', unit: 'g', calories: 350, protein: 18, carbs: 35, fat: 15, fiber: 3, sodium: 700 },
  { id: '94', name: 'Vaca atolada', category: 'Preparações', portion: '200', unit: 'g', calories: 320, protein: 22, carbs: 15, fat: 18, fiber: 4, sodium: 650 },
  { id: '95', name: 'Escondidinho de carne seca', category: 'Preparações', portion: '200', unit: 'g', calories: 380, protein: 20, carbs: 30, fat: 20, fiber: 5, sodium: 900 },
  { id: '96', name: 'Canjica', category: 'Preparações', portion: '150', unit: 'g', calories: 250, protein: 8, carbs: 40, fat: 8, fiber: 3, sodium: 100 },
  { id: '97', name: 'Brigadeiro', category: 'Açúcares e Doces', portion: '20', unit: 'g (1 unidade)', calories: 75, protein: 1, carbs: 12, fat: 2.5, fiber: 0.5, sodium: 15 },
  { id: '98', name: 'Bolo de cenoura com cobertura', category: 'Preparações', portion: '100', unit: 'g', calories: 390, protein: 5, carbs: 50, fat: 19, fiber: 2, sodium: 250 },
  { id: '99', name: 'Pastel de carne, frito', category: 'Preparações', portion: '100', unit: 'g', calories: 320, protein: 10, carbs: 25, fat: 20, fiber: 2, sodium: 600 },
  { id: '100', name: 'Acarajé', category: 'Preparações', portion: '150', unit: 'g', calories: 450, protein: 12, carbs: 30, fat: 30, fiber: 8, sodium: 400 },
  { id: '101', name: 'Arroz integral, cozido', category: 'Cereais e Derivados', portion: '100', unit: 'g', calories: 124, protein: 2.6, carbs: 25.8, fat: 0.9, fiber: 2.7, sodium: 7 },
  { id: '102', name: 'Feijão preto, cozido', category: 'Leguminosas', portion: '100', unit: 'g', calories: 77, protein: 4.5, carbs: 14, fat: 0.5, fiber: 7.9, sodium: 1 },
];
